import React from "react";

const AdminEditDel = () => {
  return (
    <>
      <ul class="save--share--pop">
        <li>Edit</li>
        <li>Delete</li>
        <li>Action 2</li>
      </ul>
    </>
  );
};
export default AdminEditDel;
