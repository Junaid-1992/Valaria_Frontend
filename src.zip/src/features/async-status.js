export const asyncStatus = Object.freeze({
    IDLE: "idle",
    LOADING: "loading",
    SUCCEEDED: "succeeded",
    ERROR: "error",
  });
  